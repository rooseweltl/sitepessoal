"""CMS leve para o site do Prof. Dr. Roosewelt Lins Silva.

Flask + SQLite: o conteúdo (perfil, linhas de pesquisa, publicações e
disciplinas) fica no banco cms.db e é editado pelo painel em /admin.
"""

import os
import secrets
import sqlite3
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "cms-rooseweltci-7f3a-9c2e-5b81-4d6a")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "cms.db")

# Credenciais iniciais do administrador — usadas apenas no primeiro boot
# para criar o usuário no banco. Troque a senha depois pelo painel
# (Perfil -> Trocar senha) ou definindo ADMIN_EMAIL/ADMIN_PASSWORD no ambiente.
ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "roosewelt.lins@ufma.br")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Biblio007@")


# ---------------------------------------------------------------------------
# Banco de dados
# ---------------------------------------------------------------------------

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Cria as tabelas e insere o conteúdo inicial (idempotente)."""
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS professor (
            id INTEGER PRIMARY KEY,
            nome TEXT NOT NULL,
            instituicao TEXT NOT NULL,
            departamento TEXT NOT NULL,
            email TEXT NOT NULL,
            lattes TEXT NOT NULL DEFAULT '',
            orcid TEXT NOT NULL DEFAULT '',
            github TEXT NOT NULL DEFAULT '',
            sobre TEXT NOT NULL,
            avatar TEXT NOT NULL DEFAULT 'RL'
        );

        CREATE TABLE IF NOT EXISTS publicacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            autores TEXT NOT NULL,
            titulo TEXT NOT NULL,
            veiculo TEXT NOT NULL,
            ano INTEGER NOT NULL,
            ordem INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS disciplinas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            nivel TEXT NOT NULL,
            periodo TEXT NOT NULL,
            ordem INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS projetos_extensao (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            descricao TEXT NOT NULL,
            periodo TEXT NOT NULL,
            ordem INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS projetos_pesquisa (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            descricao TEXT NOT NULL,
            periodo TEXT NOT NULL,
            ordem INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS admin_user (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            senha_hash TEXT NOT NULL
        );
        """
    )
    # Perfil inicial (mesmos dados do site atual).
    db.execute(
        """
        INSERT OR IGNORE INTO professor
            (id, nome, instituicao, departamento, email, lattes, orcid, github, sobre, avatar)
        VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            "Prof. Dr. Roosewelt Lins Silva",
            "Universidade Federal do Maranhão (UFMA)",
            "Departamento de Biblioteconomia e Ciência da Informação",
            "ronald.marques@ufma.br",
            "", "", "",
            "Sou professor do Departamento de Biblioteconomia e Ciência da Informação "
            "da Universidade Federal do Maranhão (UFMA). Minha trajetória une ensino e "
            "pesquisa: leciono bibliometria, metodologias de pesquisa e gestão da "
            "informação científica, e conduzo pesquisa sobre a estrutura da informação "
            "científica brasileira.\n\n"
            "Atuo como consultor em repositórios institucionais, defensor do acesso "
            "aberto e dos desenhos de políticas de ciência aberta na América Latina.",
            "RL",
        ),
    )
    # Publicações (mesmas do site atual).
    db.executemany(
        """
        INSERT OR IGNORE INTO publicacoes (id, autores, titulo, veiculo, ano, ordem)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        [
            (1, "Silva, R. L.",
             "Mapeamento bibliométrico da Ciência da Informação brasileira: redes de "
             "colaboração entre 2010 e 2020",
             "Transinformação", 2023, 1),
            (2, "Silva, R. L.; Nogueira, C.",
             "Repositórios institucionais no Brasil: cobertura, cobertura de "
             "interoperabilidade e preservação digital",
             "Ciência da Informação em Revista", 2022, 2),
            (3, "Silva, R. L.",
             "Ciência aberta na pós-graduação brasileira: práticas de acesso aberto em "
             "programas de Comunicação e Informação",
             "Anais do EnANCIB", 2021, 3),
            (4, "Silva, R. L.; Lima, J.",
             "Vocabulários controlados aplicados à representação temática em ambientes "
             "digitais de informação",
             "Ciência da Informação em Revista", 2019, 4),
        ],
    )
    # Disciplinas (mesmas do site atual).
    db.executemany(
        """
        INSERT OR IGNORE INTO disciplinas (id, nome, nivel, periodo, ordem)
        VALUES (?, ?, ?, ?, ?)
        """,
        [
            (1, "Introdução à Bibliometria", "Graduação", "2018 – atual", 1),
            (2, "Organização do Conhecimento", "Graduação", "2017 – atual", 2),
            (3, "Metodologias de Pesquisa em Biblioteconomia", "Graduação",
             "2019 – atual", 3),
            (4, "Gestão da Informação Científica", "Pós-graduação", "2019 – atual", 4),
            (5, "Tópicos: Ciência Aberta e Comunicação Científica", "Pós-graduação",
             "2022 – atual", 5),
        ],
    )
    # Projetos de extensão (iniciais).
    db.executemany(
        """
        INSERT OR IGNORE INTO projetos_extensao (id, titulo, descricao, periodo, ordem)
        VALUES (?, ?, ?, ?, ?)
        """,
        [
            (1, "Biblioteca Digital de Teses e Dissertações da UFMA",
             "Curadoria digital e ampliação da coleção de teses e dissertações, com "
             "foco em interoperabilidade OAI-PMH e preservação digital de longo prazo.",
             "2023 – atual", 1),
            (2, "Competência em Informação na Educação Básica",
             "Oficinas de letramento informacional para estudantes de escolas públicas "
             "de São Luís, promovendo o uso crítico, ético e criativo da informação.",
             "2022 – atual", 2),
            (3, "Biblioteca Comunitária Itinerante",
             "Ação extensionista que leva acervo e mediação de leitura a comunidades "
             "do interior do Maranhão, em parceria com movimentos sociais e bibliotecas públicas.",
             "2021 – 2023", 3),
            (4, "Ciência Aberta para Jovens Pesquisadores",
             "Formação de estudantes de graduação em práticas de acesso aberto, "
             "preprints e dados de pesquisa abertos.",
             "2023 – atual", 4),
        ],
    )
    # Projetos de pesquisa (exemplo — substituem as linhas de pesquisa).
    db.executemany(
        """
        INSERT OR IGNORE INTO projetos_pesquisa (id, titulo, descricao, periodo, ordem)
        VALUES (?, ?, ?, ?, ?)
        """,
        [
            (1, "Mapeamento da produção científica brasileira em Ciência da Informação",
             "Análise bibliométrica da produção nacional, identificando redes de "
             "colaboração, frentes de pesquisa e fluxos de citação entre periódicos.",
             "2021 – atual", 1),
            (2, "Repositórios institucionais e preservação digital no Maranhão",
             "Diagnóstico e arquitetura de repositórios para universidades maranhenses, "
             "com foco em interoperabilidade OAI-PMH e preservação de longo prazo.",
             "2020 – atual", 2),
            (3, "Ciência aberta na pós-graduação: práticas e políticas",
             "Estudo das práticas de acesso aberto em programas de pós-graduação "
             "brasileiros, com ênfase em preprints e dados de pesquisa abertos.",
             "2022 – atual", 3),
            (4, "Competência crítica em informação na era das fake news",
             "Pesquisa sobre competência crítica em informação de estudantes "
             "universitários frente à desinformação científica.",
             "2023 – atual", 4),
            (5, "Redes de colaboração científica na América Latina",
             "Mapeamento das redes de coautoria entre países latino-americanos nas "
             "ciências sociais e humanas.",
             "2019 – 2023", 5),
        ],
    )
    # Usuário administrador inicial (só se ainda não existir).
    db.execute(
        "INSERT OR IGNORE INTO admin_user (email, senha_hash) VALUES (?, ?)",
        (ADMIN_EMAIL, generate_password_hash(ADMIN_PASSWORD)),
    )
    db.commit()
    db.close()


init_db()


# ---------------------------------------------------------------------------
# Autenticação e CSRF
# ---------------------------------------------------------------------------

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("admin_id"):
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper


def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


@app.context_processor
def injeta_csrf():
    return {"csrf_token": csrf_token}


@app.before_request
def valida_csrf():
    if request.method == "POST" and request.form.get("_csrf") != session.get("_csrf"):
        abort(400, "Token CSRF inválido. Recarregue a página e tente novamente.")


@app.template_filter("paragrafos")
def paragrafos(texto):
    return [p.strip() for p in (texto or "").split("\n") if p.strip()]


# ---------------------------------------------------------------------------
# Site público
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    db = get_db()
    professor = db.execute("SELECT * FROM professor WHERE id = 1").fetchone()
    projetos_pesquisa = db.execute(
        "SELECT * FROM projetos_pesquisa ORDER BY ordem, id").fetchall()
    publicacoes = db.execute(
        "SELECT * FROM publicacoes ORDER BY ordem, id").fetchall()
    disciplinas = db.execute(
        "SELECT * FROM disciplinas ORDER BY ordem, id").fetchall()
    projetos_extensao = db.execute(
        "SELECT * FROM projetos_extensao ORDER BY ordem, id").fetchall()
    return render_template(
        "index.html", professor=professor, projetos_pesquisa=projetos_pesquisa,
        publicacoes=publicacoes, disciplinas=disciplinas,
        projetos_extensao=projetos_extensao,
    )


# ---------------------------------------------------------------------------
# Painel administrativo
# ---------------------------------------------------------------------------

@app.route("/admin/login", methods=["GET", "POST"])
def login():
    if session.get("admin_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")
        user = get_db().execute(
            "SELECT * FROM admin_user WHERE email = ?", (email,)
        ).fetchone()
        if user and check_password_hash(user["senha_hash"], senha):
            session.clear()
            session["admin_id"] = user["id"]
            session["admin_email"] = user["email"]
            flash("Login realizado com sucesso.", "ok")
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("E-mail ou senha inválidos.", "erro")
    return render_template("admin/login.html")


@app.route("/admin/logout", methods=["POST"])
def logout():
    session.clear()
    flash("Você saiu do painel.", "ok")
    return redirect(url_for("login"))


@app.route("/admin")
@login_required
def dashboard():
    db = get_db()
    contagens = {
        "pesquisa": db.execute(
            "SELECT COUNT(*) AS n FROM projetos_pesquisa").fetchone()["n"],
        "publicacoes": db.execute(
            "SELECT COUNT(*) AS n FROM publicacoes").fetchone()["n"],
        "disciplinas": db.execute(
            "SELECT COUNT(*) AS n FROM disciplinas").fetchone()["n"],
        "extensao": db.execute(
            "SELECT COUNT(*) AS n FROM projetos_extensao").fetchone()["n"],
    }
    return render_template("admin/dashboard.html", contagens=contagens)


@app.route("/admin/perfil", methods=["GET", "POST"])
@login_required
def perfil():
    db = get_db()
    if request.method == "POST":
        valores = {
            "nome": request.form.get("nome", "").strip(),
            "instituicao": request.form.get("instituicao", "").strip(),
            "departamento": request.form.get("departamento", "").strip(),
            "email": request.form.get("email", "").strip(),
            "lattes": request.form.get("lattes", "").strip(),
            "orcid": request.form.get("orcid", "").strip(),
            "github": request.form.get("github", "").strip(),
            "sobre": request.form.get("sobre", "").strip(),
            "avatar": request.form.get("avatar", "").strip() or "RL",
        }
        nova_senha = request.form.get("nova_senha", "")
        if nova_senha and len(nova_senha) < 8:
            flash("A nova senha precisa ter pelo menos 8 caracteres.", "erro")
            return render_template("admin/perfil.html", professor=valores)
        if not (valores["nome"] and valores["instituicao"]
                and valores["departamento"] and valores["email"]):
            flash("Preencha nome, instituição, departamento e e-mail.", "erro")
            return render_template("admin/perfil.html", professor=valores)
        db.execute(
            """UPDATE professor SET nome = ?, instituicao = ?, departamento = ?,
               email = ?, lattes = ?, orcid = ?, github = ?, sobre = ?, avatar = ?
               WHERE id = 1""",
            (valores["nome"], valores["instituicao"], valores["departamento"],
             valores["email"], valores["lattes"], valores["orcid"],
             valores["github"], valores["sobre"], valores["avatar"]),
        )
        if nova_senha:
            db.execute(
                "UPDATE admin_user SET senha_hash = ? WHERE id = ?",
                (generate_password_hash(nova_senha), session["admin_id"]),
            )
        db.commit()
        flash("Perfil salvo com sucesso.", "ok")
        return redirect(url_for("perfil"))
    professor = db.execute("SELECT * FROM professor WHERE id = 1").fetchone()
    return render_template("admin/perfil.html", professor=professor)


COLECOES = {
    "pesquisa": {
        "titulo": "Projetos de Pesquisa",
        "tabela": "projetos_pesquisa",
        "campos": [
            {"nome": "titulo", "rotulo": "Título do projeto", "tipo": "text"},
            {"nome": "descricao", "rotulo": "Descrição", "tipo": "textarea"},
            {"nome": "periodo", "rotulo": "Período", "tipo": "text"},
        ],
    },
    "publicacoes": {
        "titulo": "Publicações",
        "tabela": "publicacoes",
        "campos": [
            {"nome": "autores", "rotulo": "Autores", "tipo": "text"},
            {"nome": "titulo", "rotulo": "Título", "tipo": "text"},
            {"nome": "veiculo", "rotulo": "Veículo / Periódico", "tipo": "text"},
            {"nome": "ano", "rotulo": "Ano", "tipo": "number"},
        ],
    },
"disciplinas": {
            "titulo": "Disciplinas (Ensino)",
            "tabela": "disciplinas",
            "campos": [
                {"nome": "nome", "rotulo": "Disciplina", "tipo": "text"},
                {"nome": "nivel", "rotulo": "Nível", "tipo": "text"},
                {"nome": "periodo", "rotulo": "Período", "tipo": "text"},
            ],
        },
        "extensao": {
            "titulo": "Projetos de Extensão",
            "tabela": "projetos_extensao",
            "campos": [
                {"nome": "titulo", "rotulo": "Título do projeto", "tipo": "text"},
                {"nome": "descricao", "rotulo": "Descrição", "tipo": "textarea"},
                {"nome": "periodo", "rotulo": "Período", "tipo": "text"},
            ],
        },
    }


@app.route("/admin/colecao/<tipo>", methods=["GET", "POST"])
@login_required
def colecao(tipo):
    conf = COLECOES.get(tipo)
    if not conf:
        abort(404)
    db = get_db()
    if request.method == "POST":
        valores = {c["nome"]: request.form.get(c["nome"], "").strip()
                   for c in conf["campos"]}
        if not all(valores[c["nome"]] for c in conf["campos"]):
            flash("Preencha todos os campos.", "erro")
        else:
            nomes = ", ".join(c["nome"] for c in conf["campos"])
            marks = ", ".join("?" for _ in conf["campos"])
            proxima = db.execute(
                f"SELECT COALESCE(MAX(ordem), 0) + 1 AS o FROM {conf['tabela']}"
            ).fetchone()["o"]
            db.execute(
                f"INSERT INTO {conf['tabela']} ({nomes}, ordem) VALUES ({marks}, ?)",
                [valores[c["nome"]] for c in conf["campos"]] + [proxima],
            )
            db.commit()
            flash("Item adicionado com sucesso.", "ok")
            return redirect(url_for("colecao", tipo=tipo))
    itens = db.execute(
        f"SELECT * FROM {conf['tabela']} ORDER BY ordem, id").fetchall()
    return render_template("admin/colecao.html", conf=conf, tipo=tipo,
                           itens=itens, valores={})


@app.route("/admin/colecao/<tipo>/<int:item_id>", methods=["GET", "POST"])
@login_required
def editar_item(tipo, item_id):
    conf = COLECOES.get(tipo)
    if not conf:
        abort(404)
    db = get_db()
    item = db.execute(
        f"SELECT * FROM {conf['tabela']} WHERE id = ?", (item_id,)
    ).fetchone()
    if item is None:
        abort(404)
    if request.method == "POST":
        valores = {c["nome"]: request.form.get(c["nome"], "").strip()
                   for c in conf["campos"]}
        if not all(valores[c["nome"]] for c in conf["campos"]):
            flash("Preencha todos os campos.", "erro")
        else:
            sets = ", ".join(f"{c['nome']} = ?" for c in conf["campos"])
            db.execute(
                f"UPDATE {conf['tabela']} SET {sets} WHERE id = ?",
                [valores[c["nome"]] for c in conf["campos"]] + [item_id],
            )
            db.commit()
            flash("Item atualizado com sucesso.", "ok")
            return redirect(url_for("colecao", tipo=tipo))
        item = valores
    return render_template("admin/colecao.html", conf=conf, tipo=tipo,
                           itens=None, valores=item)


@app.route("/admin/colecao/<tipo>/<int:item_id>/excluir", methods=["POST"])
@login_required
def excluir_item(tipo, item_id):
    conf = COLECOES.get(tipo)
    if not conf:
        abort(404)
    db = get_db()
    db.execute(f"DELETE FROM {conf['tabela']} WHERE id = ?", (item_id,))
    db.commit()
    flash("Item excluído.", "ok")
    return redirect(url_for("colecao", tipo=tipo))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 80)), threaded=True)